class Bullet {
  constructor(px, py, dirX = 0, dirY = -1, spd = 10.0, size = 25.0){
    this.dirX = dirX;
    this.dirY = dirY;
    this.x = px;
    this.y = py;
    this.spd = spd;

    this.size = size;
    this.lifetime = 4.0;
    this.alive = true;
    this.hasBeenReflected = false;

    this.spawned();
  }
  spawned(){
    setTimeout(() => {
      this.alive = false;
    }, this.lifetime * 1000.0);
  }
  reflect(){
    this.hasBeenReflected = true;

    this.dirX *= -1;
    this.dirY *= -1
  }
  update(){
    this.x += this.dirX * this.spd;
    this.y += this.dirY * this.spd;
  }
  show(){
    circle(this.x, this.y, this.size);
  }
}